import mongoose from 'mongoose'

const schema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,
})

const user = mongoose.model('Usuarios', schema)

export default user;

