import { Router } from 'express'
const router = Router()

const checkAdmin = (admin) => {
    return ((req, res, next) => {
        if (admin === true) {
            next()
        } else {
            res.json({ error: -1, descripcion: `Ruta ${req.path}, Metodo ${req.method} - No autorizada` })
        }
    })
}

export default checkAdmin;