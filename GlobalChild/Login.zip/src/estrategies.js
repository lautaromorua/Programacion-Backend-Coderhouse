import { Strategy as LocalStrategy } from 'passport-local'
import { hashPassword, isValidPassword } from './services.js'
import users from './models.js'
import moongose from 'mongoose'
import { dbConection } from './DB.js'
import dotenv from 'dotenv'
dotenv.config()

moongose.connect(dbConection).then(() => console.log('Conexion establecida con mongo')).catch(error => console.log('Error', error))

const registerStrategy = new LocalStrategy({
    passReqToCallback: true
}, async (req, username, password, done) => {
    try {
        const existingUser = await users.findOne({ username })
        if (existingUser) {
            return done(null, null)
        }

        const newUser = {
            username,
            password: hashPassword(password),
            email: req.body.email
        }

        const createUser = await users.create(newUser)
        done(null, createUser)

    } catch (error) {
        console.log('Error al registrar usuario', error)
        done('Error en registro', null)
    }
}
)

const loginStrategy = new LocalStrategy(async (username, password, done) => {
    try {
        const user = await users.find({ username })
        if (!user || !isValidPassword(password, user.password))
            return done(null, null)

    } catch (error) {
        console.log("Error al loguear", error)
        done("Error login", null)
    }
});

export {
    registerStrategy,
    loginStrategy
}