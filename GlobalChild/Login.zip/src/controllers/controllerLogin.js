const controllerLog = async (req, res) => {
    return await res.render('register.ejs')
}

const controllerLogOut = async (req, res) => {
    res.session.destroy()
    return await res.render('logOut.ejs')
}

const controllerSucces = async (req, res) => {
    req.session.user = req.query.userName
    return res.redirect('api/products/all')
}

export { controllerLog, controllerLogOut, controllerSucces };