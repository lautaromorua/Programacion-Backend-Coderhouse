const dbConection = 'mongodb+srv://CoderHouse:12345@lautarocluster.j9eit.mongodb.net/?retryWrites=true&w=majorit'

export { dbConection }